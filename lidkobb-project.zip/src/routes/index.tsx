import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Mail, MapPin } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Index,
});

type Lang = "sv" | "en";

const t = {
  sv: {
    nav: { about: "Om oss", what: "Vad vi gör", contact: "Kontakt" },
    heroTagline: "Vi moderniserar administrationen för idrottsföreningar",
    heroSub: "Mindre Excel. Mer sport.",
    aboutTitle: "Om oss",
    about:
      "Vi är Nore Wahlberg och Sebastian Collis, två unga entreprenörer från Helsingborg som bygger digitala verktyg för idrottsföreningar. Vår mission är att frigöra tid från tidskrävande administration så att klubbarna kan fokusera på det som verkligen spelar roll — sporten.",
    whatTitle: "Vad vi gör",
    what:
      "Vi utvecklar ett digitalt verktyg som hjälper idrottsföreningar att slippa manuellt arbete med Excel, maillistor och medlemsregistreringar.",
    contactTitle: "Kontakt",
    contactLead: "Hör gärna av dig — vi svarar inom kort.",
    location: "Helsingborg, Sverige",
    footer: "© 2026 Lidkobb. Alla rättigheter förbehållna.",
  },
  en: {
    nav: { about: "About", what: "What we do", contact: "Contact" },
    heroTagline: "We modernize administration for sports clubs",
    heroSub: "Less spreadsheets. More sport.",
    aboutTitle: "About us",
    about:
      "We are Nore Wahlberg and Sebastian Collis, two young entrepreneurs from Helsingborg building digital tools for sports clubs. Our mission is to free up time from tedious administration so clubs can focus on what really matters — the sport.",
    whatTitle: "What we do",
    what:
      "We are building a digital tool that helps sports clubs eliminate the manual work of Excel sheets, mailing lists, and member registrations.",
    contactTitle: "Contact",
    contactLead: "Get in touch — we'll be back to you shortly.",
    location: "Helsingborg, Sweden",
    footer: "© 2026 Lidkobb. All rights reserved.",
  },
} as const;

function Logo({ className = "" }: { className?: string }) {
  return (
    <span
      className={`font-display tracking-tight leading-none ${className}`}
      style={{ letterSpacing: "-0.02em", color: "#1F5C3E" }}
    >
      Lidkobb<span>.</span>
    </span>
  );
}

function Index() {
  const [lang, setLang] = useState<Lang>("sv");
  const c = t[lang];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navbar */}
      <header className="fixed top-0 inset-x-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur-md">
        <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <a href="#top" className="flex items-center" aria-label="Lidkobb">
            <Logo className="text-xl" />
          </a>
          <div className="flex items-center gap-6">
            <ul className="hidden md:flex items-center gap-7 text-sm text-muted-foreground">
              <li><a href="#about" className="hover:text-foreground transition-colors">{c.nav.about}</a></li>
              <li><a href="#what" className="hover:text-foreground transition-colors">{c.nav.what}</a></li>
              <li><a href="#contact" className="hover:text-foreground transition-colors">{c.nav.contact}</a></li>
            </ul>
            <div
              role="group"
              aria-label="Language"
              className="flex items-center rounded-full border border-border p-0.5 text-xs font-medium"
            >
              {(["sv", "en"] as const).map((l) => (
                <button
                  key={l}
                  onClick={() => setLang(l)}
                  className={`px-3 py-1 rounded-full transition-colors ${
                    lang === l
                      ? "bg-foreground text-background"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                  aria-pressed={lang === l}
                >
                  {l.toUpperCase()}
                </button>
              ))}
            </div>
          </div>
        </nav>
      </header>

      <main id="top" className="pt-24">
        {/* Hero */}
        <section className="relative mx-auto max-w-6xl px-6 pt-20 pb-28 md:pt-32 md:pb-40">
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0 -z-10 opacity-60"
            style={{
              backgroundImage:
                "radial-gradient(60% 50% at 50% 0%, oklch(0.78 0.13 195 / 0.18), transparent 70%)",
            }}
          />
          <div className="flex flex-col items-center text-center">
            <Logo className="text-6xl md:text-8xl font-bold" />
            <h1 className="mt-10 max-w-3xl text-balance text-3xl md:text-5xl font-medium leading-[1.1] tracking-tight">
              {c.heroTagline}
            </h1>
            <p className="mt-5 max-w-xl text-base md:text-lg text-muted-foreground">
              {c.heroSub}
            </p>
            <a
              href="#contact"
              className="mt-10 inline-flex items-center gap-2 rounded-full bg-foreground text-background px-5 py-2.5 text-sm font-medium hover:bg-accent hover:text-accent-foreground transition-colors"
            >
              {c.nav.contact} →
            </a>
          </div>
        </section>

        {/* About */}
        <Section id="about" eyebrow="01" title={c.aboutTitle}>
          <p className="text-lg md:text-xl leading-relaxed text-muted-foreground text-balance">
            {c.about}
          </p>
        </Section>

        {/* What we do */}
        <Section id="what" eyebrow="02" title={c.whatTitle}>
          <p className="text-lg md:text-xl leading-relaxed text-muted-foreground text-balance">
            {c.what}
          </p>
        </Section>

        {/* Contact */}
        <Section id="contact" eyebrow="03" title={c.contactTitle}>
          <p className="text-lg md:text-xl leading-relaxed text-muted-foreground mb-10">
            {c.contactLead}
          </p>
          <div className="grid sm:grid-cols-2 gap-4">
            <a
              href="mailto:info@lidkobb.com"
              className="group flex items-center gap-4 rounded-xl border border-border bg-[var(--surface)] p-5 hover:border-accent transition-colors"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted text-accent">
                <Mail className="h-5 w-5" />
              </span>
              <span>
                <span className="block text-xs uppercase tracking-wider text-muted-foreground">Email</span>
                <span className="block text-base font-medium group-hover:text-accent transition-colors">
                  info@lidkobb.com
                </span>
              </span>
            </a>
            <div className="flex items-center gap-4 rounded-xl border border-border bg-[var(--surface)] p-5">
              <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted text-accent">
                <MapPin className="h-5 w-5" />
              </span>
              <span>
                <span className="block text-xs uppercase tracking-wider text-muted-foreground">
                  {lang === "sv" ? "Plats" : "Location"}
                </span>
                <span className="block text-base font-medium">{c.location}</span>
              </span>
            </div>
          </div>
        </Section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border/60 mt-20">
        <div className="mx-auto flex max-w-6xl flex-col sm:flex-row items-center justify-between gap-4 px-6 py-8 text-sm text-muted-foreground">
          <Logo className="text-base" />
          <p>{c.footer}</p>
        </div>
      </footer>
    </div>
  );
}

function Section({
  id,
  eyebrow,
  title,
  children,
}: {
  id: string;
  eyebrow: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section id={id} className="border-t border-border/60">
      <div className="mx-auto max-w-6xl px-6 py-24 md:py-32 grid md:grid-cols-12 gap-10">
        <div className="md:col-span-4">
          <div className="text-xs font-mono uppercase tracking-[0.2em] text-accent mb-3">
            {eyebrow}
          </div>
          <h2 className="font-display text-3xl md:text-4xl tracking-tight leading-none">
            {title}
          </h2>
        </div>
        <div className="md:col-span-8 max-w-2xl">{children}</div>
      </div>
    </section>
  );
}
